import {Component} from 'angular2/core'

@Component({
    selector: 'course',
    moduleId: module.id,
    templateUrl: './course.component.html'
})
export class CourseComponent {
    constructor(parameters) {
        
    }
}